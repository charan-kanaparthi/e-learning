import React from "react";
// nodejs library that concatenates classes
import classNames from "classnames";
// @material-ui/core components
import withStyles from "@material-ui/core/styles/withStyles";
import "../../../node_modules/video-react/dist/video-react.css";
// @material-ui/icons
import "./loadcourse.css"
// core components
import Header from "components/Header/Header.jsx";
import Footer from "components/Footer/Footer.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import GridItem from "components/Grid/GridItem.jsx";
import Button from "components/CustomButtons/Button.jsx";
import HeaderLinks from "components/Header/HeaderLinks.jsx";
import Parallax from "components/Parallax/Parallax.jsx";
 import landingPageStyle from "assets/jss/material-kit-react/views/landingPage.jsx";
 import Card from "components/Card/Card.jsx";
 import CardBody from "components/Card/CardBody.jsx";
 import CardHeader from "components/Card/CardHeader.jsx";
 import image1 from "assets/images/course_4.jpg";
 import image2 from "assets/images/course_5.jpg";
 import { Container, Row, Col } from 'reactstrap';
 import Face from "@material-ui/icons/Face";
import Chat from "@material-ui/icons/Chat";
import Build from "@material-ui/icons/Build";
// core components
import CustomTabs from "components/CustomTabs/CustomTabs.jsx";
//  import Button from "components/CustomButtons/Button.jsx";
// import "node_modules/video-react/dist/video-react.css";
import { Player } from 'video-react';

const dashboardRoutes = [];

class LoadCoursePage extends React.Component {
    constructor(props) {
        super(props);
        console.log(props.history.location)
    // this.state={videos: [
    //      'https://s3.amazonaws.com/codecademy-content/courses/React/react_video-fast.mp4',
    //     'https://s3.amazonaws.com/codecademy-content/courses/React/react_video-slow.mp4',
    //    'https://s3.amazonaws.com/codecademy-content/courses/React/react_video-cute.mp4',
    //   'https://s3.amazonaws.com/codecademy-content/courses/React/react_video-eek.mp4'
    // ]}
    }
      
  render() {
    const { classes, ...rest } = this.props;
    return (
      <div>
        <Header
          color="transparent"
          routes={dashboardRoutes}
          brand="Material Kit React"
          rightLinks={<HeaderLinks />}
          fixed
          changeColorOnScroll={{
            height: 400,
            color: "white"
          }}
          {...rest}
        />
        <Parallax filter  style={{height:"30vh"}}>
          <div className={classes.container}>
            <GridContainer>
              <GridItem xs={12} sm={12} md={6}>
                <h1 className={classes.title}>Courses</h1>
              
                <br />
            
              </GridItem>
            </GridContainer>
          </div>
        </Parallax>
        <div className={classNames(classes.main, classes.mainRaised)}>
          <div className={classes.container}>
          <br/>
      {
           
        //   <Card>
        //   <CardBody>
        //      <Player
        //      playsInline
        //      poster="/assets/poster.png"
        //      src={video_url}
        //    /> 
           
        //    </CardBody>
        //    </Card>
         // )
        //  <h4 key={video_url} className={ "in-active"} >
        //  { video_url}
        //   </h4>
      }
    
      
     
          </div>
        </div>

        <div className="course">
		<Container>
			<Row>
				<Col lg="8" >
					
					<div className="course_container" style={{textAlign:"center"}}>
						<div className="course_title">Data Scientist</div>
		              <div className="course_image"><img src={require("assets/images/course_image.jpg")} alt=""/></div>

                        <div style={{width:"53%",marginLeft:"23%"}}>
                        <CustomTabs
                          headerColor="primary"
                          tabs={[
                            {
                              tabName: "Description",
                              tabIcon: Face,
                              tabContent: (
                                <p className={classes.textCenter}>
                                A Data Scientist that will helps to  discover the information hidden in vast amounts of data,
                                 and helps to make smarter decisions to deliver even better products.
                                  The primary focus will be in applying data mining techniques, 
                                  doing statistical analysis, and building high quality prediction systems .
                                </p>
                              )
                            },
                            {
                              tabName: "Curriculum",
                              tabIcon: Chat,
                              tabContent: (
                                <p className={classes.textCenter}>
                                  I think that’s a responsibility that I have, to push
                                  possibilities, to show people, this is the level that
                                  things could be at. I will be the leader of a company
                                  that ends up being worth billions of dollars, because
                                  I got the answers. I understand culture. I am the
                                  nucleus. I think that’s a responsibility that I have,
                                  to push possibilities, to show people, this is the
                                  level that things could be at.
                                </p>
                              )
                            },
                            {
                              tabName: "Reviews",
                              tabIcon: Build,
                              tabContent: (
                                <p className={classes.textCenter}>
                                  think that’s a responsibility that I have, to push
                                  possibilities, to show people, this is the level that
                                  things could be at. So when you get something that has
                                  the name Kanye West on it, it’s supposed to be pushing
                                  the furthest possibilities. I will be the leader of a
                                  company that ends up being worth billions of dollars,
                                  because I got the answers. I understand culture. I am
                                  the nucleus.
                                </p>
                              )
                            }
                          ]}
                        />
                      </div>
					
					</div>
			</Col>

				
				<div className="col-lg-4">
					<div className="sidebar" >

						
						<div className="sidebar_section">
							<div className="sidebar_section_title">Course Feature</div>
							<div className="sidebar_feature">
								<div className="course_price">$180</div>

								<div className="feature_list">

									
									<div className="feature d-flex flex-row align-items-center justify-content-start">
										<div className="feature_title"><i className="fa fa-clock-o" aria-hidden="true"></i><span>Duration:</span></div>
										<div className="feature_text ml-auto">2 weeks</div>
									</div>

									
									<div className="feature d-flex flex-row align-items-center justify-content-start">
										<div className="feature_title"><i className="fa fa-file-text-o" aria-hidden="true"></i><span>Lectures:</span></div>
										<div className="feature_text ml-auto">10</div>
									</div>

									
									<div className="feature d-flex flex-row align-items-center justify-content-start">
										<div className="feature_title"><i className="fa fa-question-circle-o" aria-hidden="true"></i><span>Lectures:</span></div>
										<div className="feature_text ml-auto">6</div>
									</div>

									
									<div className="feature d-flex flex-row align-items-center justify-content-start">
										<div className="feature_title"><i className="fa fa-list-alt" aria-hidden="true"></i><span>Lectures:</span></div>
										<div className="feature_text ml-auto">Yes</div>
									</div>

									
									<div className="feature d-flex flex-row align-items-center justify-content-start">
										<div className="feature_title"><i className="fa fa-users" aria-hidden="true"></i><span>Lectures:</span></div>
										<div className="feature_text ml-auto">35</div>
									</div>

								</div>
							</div>
						</div>

				
						<div className="sidebar_section">
							<div className="sidebar_section_title">Teacher</div>
							<div className="sidebar_teacher">
								<div className="teacher_title_container d-flex flex-row align-items-center justify-content-start">
									<div className="teacher_image"><img src={require("assets/images/teacher.jpg")} alt=""/></div>
									<div className="teacher_title">
										<div className="teacher_name"><a href="#">Jacke Masito</a></div>
										<div className="teacher_position">Marketing & Management</div>
									</div>
								</div>
								<div className="teacher_meta_container">
					
									<div className="teacher_meta d-flex flex-row align-items-center justify-content-start">
										<div className="teacher_meta_title">Average Rating:</div>
										<div className="teacher_meta_text ml-auto"><span>4.7</span><i className="fa fa-star" aria-hidden="true"></i></div>
									</div>
									
									<div className="teacher_meta d-flex flex-row align-items-center justify-content-start">
										<div className="teacher_meta_title">Review:</div>
										<div className="teacher_meta_text ml-auto"><span>12k</span><i className="fa fa-comment" aria-hidden="true"></i></div>
									</div>
								
									<div className="teacher_meta d-flex flex-row align-items-center justify-content-start">
										<div className="teacher_meta_title">Quizzes:</div>
										<div className="teacher_meta_text ml-auto"><span>600</span><i className="fa fa-user" aria-hidden="true"></i></div>
									</div>
								</div>
								<div className="teacher_info">
									<p>Hi! I am Masion, I’m a marketing & management  eros pulvinar velit laoreet, sit amet egestas erat dignissim. Sed quis rutrum tellus, sit amet viverra felis. Cras sagittis sem sit amet urna feugiat rutrum nam nulla ipsum.</p>
								</div>
							</div>
						</div>

						
						<div className="sidebar_section">
							<div className="sidebar_section_title">Latest Courses</div>
							<div className="sidebar_latest">

								
								<div className="latest d-flex flex-row align-items-start justify-content-start">
									<div className="latest_image"><div><img src={require("assets/images/latest_1.jpg")} alt=""/></div></div>
									<div className="latest_content">
										<div className="latest_title"><a href="course.html">How to Design a Logo a Beginners Course</a></div>
										<div className="latest_price">Free</div>
									</div>
								</div>

								
								<div className="latest d-flex flex-row align-items-start justify-content-start">
									<div className="latest_image"><div><img src={require("assets/images/latest_2.jpg")} alt=""/></div></div>
									<div className="latest_content">
										<div className="latest_title"><a href="course.html">Photography for Beginners Masterclass</a></div>
										<div className="latest_price">$170</div>
									</div>
								</div>

								
								<div className="latest d-flex flex-row align-items-start justify-content-start">
									<div className="latest_image"><div><img src={require("assets/images/latest_3.jpg")} alt=""/></div></div>
									<div className="latest_content">
										<div className="latest_title"><a href="course.html">The Secrets of Body Language</a></div>
										<div className="latest_price">$220</div>
									</div>
								</div>

							</div>
						</div>

					</div>
				</div>
			</Row>
		</Container>
	</div>
        <Footer />
      </div>
    );
  }
}

export default withStyles(landingPageStyle)(LoadCoursePage);
